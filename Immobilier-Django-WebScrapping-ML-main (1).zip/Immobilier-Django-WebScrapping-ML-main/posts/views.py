from django.contrib.messages.api import success
from django.core import paginator
from django.db.models import Count, Q
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, get_object_or_404, redirect, reverse
from django.views.generic import View, ListView, DetailView, CreateView, UpdateView, DeleteView

from .forms import CommentForm, PostForm, CreateUserForm
from .models import Category, Post, Author, PostView
from marketing.forms import EmailSignupForm
from marketing.models import Signup

from django.contrib.auth import authenticate, login, logout
from django.core.mail import EmailMessage
from django.conf import settings

import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer

import pickle
loaded_model = pickle.load(open("posts/finalized_model.sav", 'rb'))


form = EmailSignupForm()


def get_author(user):
    qs = Author.objects.filter(user=user)
    if qs.exists():
        return qs[0]
    return None


class SearchView(View):
    def get(self, request, *args, **kwargs):
        queryset = Post.objects.all()
        query = request.GET.get('q')
        if query:
            queryset = queryset.filter(
                Q(title__icontains=query) |
                Q(overview__icontains=query) 
            ).distinct()
        context = {
            'queryset': queryset
        }
        return render(request, 'search_results.html', context)


def search(request):
    queryset = Post.objects.all()
    query = request.GET.get('q')
    if query:
        queryset = queryset.filter(
            Q(title__icontains=query) |
            Q(overview__icontains=query)
        ).distinct()
    context = {
        'queryset': queryset
    }
    return render(request, 'search_results.html', context)


def get_category_count():
    queryset = Post \
        .objects \
        .values('categories__title') \
        .annotate(Count('categories__title'))
    return queryset


class IndexView(View):
    form = EmailSignupForm()

    def get(self, request, *args, **kwargs):
        featured = Post.objects.filter(featured=True)
        latest = Post.objects.order_by('-timestamp')[0:3]
        context = {
            'object_list': featured,
            'latest': latest,
            'form': self.form
        }
        return render(request, 'index.html', context)

    def post(self, request, *args, **kwargs):
        email = request.POST.get("email")
        new_signup = Signup()
        new_signup.email = email
        new_signup.save()
        messages.info(request, "Successfully subscribed")
        return redirect("home")


def index(request):
    featured = Post.objects.filter(featured=True)
    latest = Post.objects.order_by('-timestamp')[0:3]

    if request.method == "POST":
        email = request.POST["email"]
        new_signup = Signup()
        new_signup.email = email
        new_signup.save()

    context = {
        'object_list': featured,
        'latest': latest,
        'form': form
    }
    return render(request, 'index.html', context)


class PostListView(ListView):
    form = EmailSignupForm()
    model = Post
    template_name = 'blog.html'
    context_object_name = 'queryset'
    paginate_by = 4

    def get_context_data(self, **kwargs):
        category_count = get_category_count()
        most_recent = Post.objects.order_by('-timestamp')[:3]
        context = super().get_context_data(**kwargs)
        context['most_recent'] = most_recent
        context['page_request_var'] = "page"
        context['category_count'] = category_count
        context['form'] = self.form
        return context


def post_list(request):
    category_count = get_category_count()
    most_recent = Post.objects.order_by('-timestamp')[:3]
    post_list = Post.objects.all()
    paginator = Paginator(post_list, 4)
    page_request_var = 'page'
    page = request.GET.get(page_request_var)
    try:
        paginated_queryset = paginator.page(page)
    except PageNotAnInteger:
        paginated_queryset = paginator.page(1)
    except EmptyPage:
        paginated_queryset = paginator.page(paginator.num_pages)

    context = {
        'queryset': paginated_queryset,
        'most_recent': most_recent,
        'page_request_var': page_request_var,
        'category_count': category_count,
        'form': form
    }
    return render(request, 'blog.html', context)


class PostDetailView(DetailView):
    model = Post
    template_name = 'post.html'
    context_object_name = 'post'
    form = CommentForm()

    def get_object(self):
        obj = super().get_object()
        if self.request.user.is_authenticated:
            PostView.objects.get_or_create(
                user=self.request.user,
                post=obj
            )
        return obj

    def get_context_data(self, **kwargs):
        category_count = get_category_count()
        most_recent = Post.objects.order_by('-timestamp')[:3]
        context = super().get_context_data(**kwargs)
        context['most_recent'] = most_recent
        context['page_request_var'] = "page"
        context['category_count'] = category_count
        context['form'] = self.form
        df = pd.read_csv("posts/data.csv")
        id = super().get_object().id
        obj = df.index[df.Idpost == id].tolist()
        cm = CountVectorizer().fit_transform(df['important_features'])
        cs = cosine_similarity(cm)
        scores = list(enumerate(cs[obj[0]]))
        sorted_scores = sorted(scores, key=lambda x: x[1], reverse=True)
        sorted_scores = sorted_scores[1:4]
        ids_list = []
        for i in sorted_scores:
            ids_list = ids_list + [df.loc[i[0]]["Idpost"]]
        context['recommended1'] = Post.objects.filter(id=ids_list[0])
        context['recommended2'] = Post.objects.filter(id=ids_list[1])
        context['recommended3'] = Post.objects.filter(id=ids_list[2])
        return context

    def post(self, request, *args, **kwargs):
        form = CommentForm(request.POST)
        if form.is_valid():
            post = self.get_object()
            form.instance.user = request.user
            form.instance.post = post
            form.save()
            return redirect(reverse("post-detail", kwargs={
                'pk': post.pk
            }))


def post_detail(request, id):
    category_count = get_category_count()
    most_recent = Post.objects.order_by('-timestamp')[:3]
    post = get_object_or_404(Post, id=id)

    if request.user.is_authenticated:
        PostView.objects.get_or_create(user=request.user, post=post)

    form = CommentForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            form.instance.user = request.user
            form.instance.post = post
            form.save()
            return redirect(reverse("post-detail", kwargs={
                'id': post.pk
            }))
    context = {
        'post': post,
        'most_recent': most_recent,
        'category_count': category_count,
        'form': form,
    }
    return render(request, 'post.html', context)


class PostCreateView(CreateView):
    model = Post
    template_name = 'post_create.html'
    form_class = PostForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Ajouter'
        return context

    def form_valid(self, form):
        form.instance.author = get_author(self.request.user)
        form.save()
        obj = Post.objects.get(pk=form.instance.pk)
        pieces = obj.roomCount + obj.bathroomCount
        data = {
            "Idpost": [form.instance.pk],
            'important_features': [str(obj.typies)+' '+str(obj.price)+' '+str(obj.address.split(' ')[-1])+' ' + str(
                obj.surface)+' '+str(pieces)+' '+str(obj.roomCount)+' '+str(obj.bathroomCount)]
        }
        df = pd.DataFrame(data)
        df.to_csv(r"posts/data.csv",
                  mode='a', header=False, index=False)
        return redirect(reverse("post-detail", kwargs={
            'pk': form.instance.pk
        }))


def post_create(request):
    title = 'Ajouter'
    form = PostForm(request.POST or None, request.FILES or None)
    author = get_author(request.user)
    if request.method == "POST":
        if form.is_valid():
            form.instance.author = author
            form.save()
            return redirect(reverse("post-detail", kwargs={
                'id': form.instance.id
            }))
    context = {
        'title': title,
        'form': form
    }
    return render(request, "post_create.html", context)


class PostUpdateView(UpdateView):
    model = Post
    template_name = 'post_create.html'
    form_class = PostForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Modifier'
        return context

    def form_valid(self, form):
        form.instance.author = get_author(self.request.user)
        form.save()
        df1 = pd.read_csv("posts/data.csv")
        numpy_df = df1.to_numpy()
        index_arr = np.where(numpy_df[:, 0] == form.instance.id)
        del_arr = np.delete(numpy_df, index_arr, axis=0)
        df1 = pd.DataFrame(del_arr, columns=["Idpost", "important_features"])
        df1.to_csv(r"posts/data.csv", index=False)
        obj = Post.objects.get(pk=form.instance.pk)
        pieces = obj.roomCount + obj.bathroomCount
        data = {
            "Idpost": [form.instance.pk],
            'important_features': [str(obj.typies)+' '+str(obj.price)+' '+str(obj.address.split(' ')[-1])+' ' + str(
                obj.surface)+' '+str(pieces)+' '+str(obj.roomCount)+' '+str(obj.bathroomCount)]
        }
        df2 = pd.DataFrame(data)
        df2.to_csv(r"posts/data.csv",
                   mode='a', header=False, index=False)
        return redirect(reverse("post-detail", kwargs={
            'pk': form.instance.pk
        }))


def post_update(request, id):
    title = 'Modifier'
    post = get_object_or_404(Post, id=id)
    form = PostForm(
        request.POST or None,
        request.FILES or None,
        instance=post)
    author = get_author(request.user)
    if request.method == "POST":
        if form.is_valid():
            form.instance.author = author
            form.save()
            return redirect(reverse("post-detail", kwargs={
                'id': form.instance.id
            }))
    context = {
        'title': title,
        'form': form
    }
    return render(request, "post_create.html", context)



class PostDeleteView(DeleteView):
    model = Post
    success_url = '/blog'
    template_name = 'post_confirm_delete.html'


def post_delete(request, id):
    post = get_object_or_404(Post, id=id)
    post.delete()
    return redirect(reverse("post-list"))


def registerPage(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Le compte a été créé pour ' + user)

            return redirect('login')

    context = {
        'form': form
    }
    return render(request, "register.html", context)


def loginPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('login')


def recommendationView(request):
    category_count = get_category_count()
    most_recent = Post.objects.order_by('-timestamp')[:3]
    recommendation_list = Post.objects.all()
    new_recommendation_list = sorted(
        recommendation_list, key=lambda x: x.view_count, reverse=True)

    paginator = Paginator(new_recommendation_list, 4)
    page_request_var = 'page'
    page = request.GET.get(page_request_var)
    try:
        paginated_queryset = paginator.page(page)
    except PageNotAnInteger:
        paginated_queryset = paginator.page(1)
    except EmptyPage:
        paginated_queryset = paginator.page(paginator.num_pages)
    context = {
        'queryset': paginated_queryset,
        'most_recent': most_recent,
        'page_request_var': page_request_var,
        'category_count': category_count,
    }
    return render(request, 'recommendation.html', context)


def contactView(request):
    if request.method == "POST":
        username_message = request.POST['username']
        email_message = request.POST['email']
        message = request.POST['message']
        EmailMessage(
            username_message,
            message,
            email_message,
            [settings.EMAIL_HOST_USER],
        )
        messages.info(
            request, 'Votre message est bien reçu Ms / Mme : '+username_message)
        return render(request, 'contact.html', {})

    else:
        return render(request, 'contact.html', {})


villeandid = pd.read_csv("posts/ville.csv")


def estimationView(request):
    if request.method == 'POST':
        type_id = request.POST.get('type')
        surface = request.POST.get('surface')
        ville = request.POST.get('ville').capitalize()
        ville_id = villeandid[villeandid.Ville == ville]['Id_ville']
        nb_pieces = request.POST.get('nb_pieces')
        nb_chambres = request.POST.get('nb_chambres')
        nb_salles_bain = request.POST.get('nb_salles_bain')
        data = {'Id_type': [type_id], 'Surface_metre_carre': [surface], 'Id_ville': [
            ville_id], 'nb_pieces': [nb_pieces], 'nb_chambres': [nb_chambres], 'nb_salles_bain': [nb_salles_bain]}
        dfdata = pd.DataFrame(data)
        predection = loaded_model.predict(dfdata)
        context = {
            'prediction': predection[0],
        }

        messages.info(
            request, 'Le prix estimé de votre bien est : '+str(int(predection))+' DH')

        return render(request, 'estimation.html', context)

    else:
        return render(request, 'estimation.html', {})
